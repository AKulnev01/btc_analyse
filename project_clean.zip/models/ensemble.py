# models/ensemble.py
from __future__ import annotations
import pickle
from typing import Dict, List, Optional
import numpy as np
import pandas as pd

__all__ = ["predict_pack", "ensemble_predict"]

def predict_pack(df: pd.DataFrame, pack_path: str) -> Dict[str, float]:
    """Единый предикт классических квантильных паков (LGBM/CAT/XGB)."""
    with open(pack_path, "rb") as f:
        pack = pickle.load(f)
    models = pack["models"]
    feature_cols = pack.get("feature_cols") or pack.get("features")
    if feature_cols is None:
        raise ValueError("Pack missing 'feature_cols'/'features'.")
    scale_col = pack["scale_col"]
    quantiles = pack["quantiles"]

    # определить структуру: models[q] или models[h][q]
    h = None
    if isinstance(models, dict) and models:
        first_val = next(iter(models.values()))
        if isinstance(first_val, dict):  # models[h][q]
            h = sorted(models.keys())[0]

    row = df.dropna(subset=["y", scale_col]).iloc[-1]
    X = row[feature_cols].astype(float).values.reshape(1, -1)
    sigma = float(row[scale_col])
    now_price = float(row["close"])

    preds_scaled = []
    if h is not None:
        for q in quantiles:
            m = models[h][q]
            preds_scaled.append(float(m.predict(X)[0]))
    else:
        for q in quantiles:
            m = models[q]
            preds_scaled.append(float(m.predict(X)[0]))

    preds_scaled = np.array(preds_scaled, dtype=float)
    preds_scaled.sort()  # safety
    yq = preds_scaled * sigma
    return {
        "now_price": now_price,
        "P10": float(now_price * np.exp(yq[0])),
        "P50": float(now_price * np.exp(yq[1])),
        "P90": float(now_price * np.exp(yq[2])),
    }

# back-compat alias
_predict_pack = predict_pack

def _predict_seq(df: pd.DataFrame, backend: str, model_path: str, meta_path: str, device: str = "cpu") -> Dict[str, float]:
    if backend == "gru":
        from models.nn_seq import predict_now as _pred
    elif backend == "tcn":
        from models.tcn_seq import predict_now_tcn as _pred
    else:
        raise ValueError(f"unknown seq backend: {backend}")
    return _pred(df, model_path=model_path, meta_path=meta_path, device=device)

def ensemble_predict(
    df: pd.DataFrame,
    classical_packs: Optional[List[str]] = None,
    seq_models: Optional[List[Dict]] = None,
    weights: Optional[List[float]] = None,
) -> Dict[str, float]:
    classical_packs = classical_packs or []
    seq_models = seq_models or []
    preds: List[Dict[str, float]] = []

    for p in classical_packs:
        preds.append(predict_pack(df, p))
    for m in seq_models:
        preds.append(_predict_seq(df, m["backend"], m["model"], m["meta"], device=m.get("device", "cpu")))

    if not preds:
        raise ValueError("No models provided for ensemble.")

    if weights is None:
        weights = [1.0] * len(preds)
    w = np.array(weights, dtype=float)
    w = w / w.sum()

    now_price = preds[0]["now_price"]
    P10 = float(np.sum([w[i] * preds[i]["P10"] for i in range(len(preds))]))
    P50 = float(np.sum([w[i] * preds[i]["P50"] for i in range(len(preds))]))
    P90 = float(np.sum([w[i] * preds[i]["P90"] for i in range(len(preds))]))
    P10, P90 = float(min(P10, P50)), float(max(P90, P50))
    return {"now_price": now_price, "P10": P10, "P50": P50, "P90": P90}